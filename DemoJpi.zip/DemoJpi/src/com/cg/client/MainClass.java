/**
 * 
 */
package com.cg.client;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.entity.Employee;

/**
 * @author jesorj
 *
 */
public class MainClass {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager manager=factory.createEntityManager();
		manager.getTransaction().begin();
		Employee emp=new Employee();
		emp.setEmpName("Abhinash");
		emp.setEmpSal(30000);
		manager.persist(emp);
		manager.getTransaction().commit();
		manager.close();
		System.out.println("Added Employee");
		
		factory.close();
		
	}

}
