package com.cg.client;

import java.util.List;

import javax.management.Query;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.cg.entity.Employee;



public class TypeDemo {

	public static void main(String[] args) {
		

		
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager manager=factory.createEntityManager();
		manager.getTransaction().begin();

		String qry="SELECT emp FROM Employee emp WHERE emp.empSal>=30000 AND emp.empSal<=40000";
	TypedQuery<Employee> query=manager.createQuery(qry, Employee.class);	
	
		List list=query.getResultList();
		for(Object obj :list)
		{
			System.out.println(obj);
		}
		manager.getTransaction().commit();
		System.out.println("updated");
		manager.close();
		factory.close();

	}

}
